package com.example.finalproject

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.RadioButton
import android.widget.Toast
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class Firstscreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.firstscreen)

        val UsernameInput = findViewById<EditText>(R.id.usernameInput)
        val startQuizBtn = findViewById<Button>(R.id.startQuizBtn)
        val difficultyGroup = findViewById<RadioGroup>(R.id.difficultyGroup)

        startQuizBtn.setOnClickListener {
            val username = UsernameInput.text.toString().trim()
            val DifficultyId = difficultyGroup.checkedRadioButtonId

              if (username.isEmpty()) {
                Toast.makeText(this, "Please enter your username", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

              if (DifficultyId == -1) { 
                Toast.makeText(this, "Please select a difficulty level", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val RadBtn = findViewById<RadioButton>(DifficultyId)
             val difficulty = RadBtn.text.toString()
            Log.d("Difficulty", "Selected difficulty by the user is: $difficulty")


            val intent = Intent(this, QuizActivity::class.java)
            intent.putExtra("username", username)
            intent.putExtra("difficulty", difficulty)
              startActivity(intent)
        }
    }
}
