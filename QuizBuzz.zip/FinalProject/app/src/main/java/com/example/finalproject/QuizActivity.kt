package com.example.finalproject

import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.os.CountDownTimer
import android.widget.*
import android.util.Log
import android.content.Intent

class QuizActivity : AppCompatActivity() {

    data class QuizQuestion(
        val question: String,
        val options: List<String>,
        val correctAnswer: String,
        val difficulty: String
    )

    private lateinit var questionText: TextView
    private lateinit var timerText: TextView
    private lateinit var optionsGroup: RadioGroup
    private lateinit var submitButton: Button


    private val questions = listOf(
        QuizQuestion("What is the capital of France?", listOf("Berlin", "Madrid", "Paris", "Rome"), "Paris", "Easy"),
        QuizQuestion("Which planet is known as the Red Planet?", listOf("Earth", "Mars", "Jupiter", "Saturn"), "Mars", "Easy"),
        QuizQuestion("What is the boiling point of water?", listOf("90°C", "100°C", "110°C", "120°C"), "100°C", "Easy"),
        QuizQuestion("Who is formula of Potassium?", listOf("Cs","K","Ca","Na"),"K","Easy"),
        QuizQuestion("What is Capital of India?", listOf("New Delhi","Bihar","UP","Assam"),"New Delhi","Easy"),
        QuizQuestion("Who is Divyansh Goyal?", listOf("Cricketer","Monk","Student","Prisoner"),"Student","Easy"),
        QuizQuestion("What is the currency of Japan?", listOf("Dollar", "Euro", "Yen", "Peso"), "Yen", "Easy"),
        QuizQuestion("What is the Language of Japan?", listOf("Hindi", "European", "Japanese", "Sanskrit"), "Japanese", "Easy"),
        QuizQuestion("What is the animal among them?", listOf("Key", "Mouse", "Laptop", "Pacific"), "Mouse", "Easy"),
        QuizQuestion("What is organ here?", listOf("Water", "Food", "Kidney", "Burger"), "Kidney", "Easy"),

        QuizQuestion("Who wrote 'Hamlet'?", listOf("Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"), "William Shakespeare", "Medium"),
        QuizQuestion("How many continents are there?", listOf("5", "6", "7", "8"), "7", "Medium"),
        QuizQuestion("Which element has the chemical symbol 'O'?", listOf("Gold", "Oxygen", "Osmium", "Hydrogen"), "Oxygen", "Medium"),
        QuizQuestion("Who is derivative of X^3?", listOf("3X^2","6X","3X^2","12X"),"3X^2","Medium"),
        QuizQuestion("Who is Divyansh Goyal?", listOf("Cricketer","Monk","Student","Prisoner"),"Student","Medium"),
        QuizQuestion("What is the My favorite ?", listOf("Burger", "Maggi", "Ghar ka khana", "Hostel"), "Ghar ka khana", "Medium"),
        QuizQuestion("What is easiest to do?", listOf("Classes", "Programming", "Scrolling Reel", "Development"), "Scrolling Reel", "Medium"),
        QuizQuestion("What is the RAM?", listOf("Random Access Memory", "Rose Are Magnificient", "Right Access Memory", "None"), "Random Access Memory", "Medium"),
        QuizQuestion("What is the largest ocean on Earth?", listOf("Atlantic", "Indian", "Arctic", "Pacific"), "Pacific", "Medium"),
        QuizQuestion("Will RCB win IPL 2025?", listOf("Probably YES", "No Chance", "Can't Say", "None of Above"), "Can't Say", "Medium"),

        QuizQuestion("What is the currency of India?", listOf("Yen", "Euro", "Rupee", "Dollar"), "Rupee", "Hard"),
        QuizQuestion("What language is primarily spoken in Brazil?", listOf("Spanish", "Portuguese", "English", "French"), "Portuguese", "Hard"),
        QuizQuestion("Who Recited BHAGVAD GITA?", listOf("Lord Krishna","Lord Shiva","Lord Ganesha","Lord Kartikeya"),"Lord Krishna","Hard"),
        QuizQuestion("What is the largest ocean on Earth?", listOf("Atlantic", "Indian", "Arctic", "Pacific"), "Pacific", "Hard"),
        QuizQuestion("Who developed the theory of relativity?", listOf("Isaac Newton", "Nikola Tesla", "Albert Einstein", "Galileo Galilei"), "Albert Einstein", "Hard"),
       QuizQuestion("Which country has the most natural lakes?", listOf("Canada", "Russia", "USA", "India"), "Canada", "Hard"),
    QuizQuestion("What is the smallest prime number?", listOf("0", "1", "2", "3"), "2", "Hard"),
    QuizQuestion("What is the heaviest naturally occurring element?", listOf("Uranium", "Plutonium", "Osmium", "Lead"), "Uranium", "Hard"),
    QuizQuestion("Which blood type is known as the universal donor?", listOf("AB+", "O-", "A+", "B-"), "O-", "Hard"),
    QuizQuestion("In which year did the Berlin Wall fall?", listOf("1987", "1989", "1991", "1993"), "1989", "Hard")

    )

    private lateinit var Questions: List<QuizQuestion>
    private var currQuesIdx = 0
    private var timer: CountDownTimer? = null
    private val questionTime: Long = 15000
    private var score = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContentView(R.layout.quiz)

        questionText = findViewById(R.id.questionText)
        timerText = findViewById(R.id.timerText)
        optionsGroup = findViewById(R.id.optionsGroup)
        submitButton = findViewById(R.id.submitAnswerBtn)
        
        val difficulty = intent.getStringExtra("difficulty") ?: "Easy"
        Questions = questions.filter { it.difficulty.equals(difficulty, ignoreCase = true) }


        Log.d("QuizActivity", "Quiz started with difficulty: $difficulty")
           loadQuestion()

        submitButton.setOnClickListener {
               val selectedId = optionsGroup.checkedRadioButtonId
            if (selectedId == -1) 
            {
                Toast.makeText(this, "Select an answer!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            timer?.cancel() 
              val selectedOption = findViewById<RadioButton>(selectedId)
            val currQues = Questions[currQuesIdx]


            when (difficulty) {
                "Easy" -> {
                    if (selectedOption.text == currQues.correctAnswer)
                    {
                        score += 1
                        Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show()
                    }

                    else
                    {
                        Toast.makeText(this,"Wrong! The correct answer is ${currQues.correctAnswer}",Toast.LENGTH_SHORT).show()
                    }
                }
                "Medium" -> {
                    if (selectedOption.text == currQues.correctAnswer) {
                        score += 1
                        Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show()
                    } else {
                        score -= 0.5
                        Toast.makeText(this,"Wrong! The correct answer is ${currQues.correctAnswer}",Toast.LENGTH_SHORT).show()
                    }
                }
                "Hard" -> {
                    if (selectedOption.text == currQues.correctAnswer) {
                        score += 1
                        Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show()
                    } else {
                        score -= 1
                        Toast.makeText(this,"Wrong! The correct answer is ${currQues.correctAnswer}",Toast.LENGTH_SHORT).show()
                    }
                }
            }

            nextQuestion()
        }
    }

    private fun loadQuestion() {
        if (currQuesIdx >= Questions.size) {
            Toast.makeText(this, "Quiz Completed!", Toast.LENGTH_LONG).show()

            val resIntent = Intent(this, Result::class.java)
            val username = intent.getStringExtra("username") ?: "Guest"
            val difficulty = intent.getStringExtra("difficulty") ?: "NotSelected"

            resIntent.putExtra("username", username)
            resIntent.putExtra("difficulty", difficulty)
            resIntent.putExtra("score", score)
            Log.d("Result", "username: $username, score: $score, difficulty: $difficulty")
            startActivity(resIntent)

            return
        }

        optionsGroup.clearCheck()
        submitButton.isEnabled = true

        val current = Questions[currQuesIdx]
        questionText.text = current.question


        setOptions(current.options)
        startTimer()
    }

    private fun setOptions(options: List<String>) {
        val buttons = listOf(
            findViewById<RadioButton>(R.id.optionA),
            findViewById<RadioButton>(R.id.optionB),
            findViewById<RadioButton>(R.id.optionC),
            findViewById<RadioButton>(R.id.optionD)
        )
        for (i in buttons.indices) {
            buttons[i].text = options[i]
        }
    }

    private fun nextQuestion() {
        currQuesIdx++
        loadQuestion()
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(questionTime, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timerText.text = "Time: ${millisUntilFinished / 1000}s"
            }

            override fun onFinish() {
                Toast.makeText(this@QuizActivity, "Time's up!", Toast.LENGTH_SHORT).show()
                nextQuestion()
            }
        }.start()
    }
}
