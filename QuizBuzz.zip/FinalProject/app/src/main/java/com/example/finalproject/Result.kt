package com.example.finalproject

import android.animation.ObjectAnimator
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class Result : AppCompatActivity() {

    private lateinit var usernameText: TextView
    private lateinit var difficultyText: TextView
    private lateinit var scoreText: TextView
    private lateinit var circleProgress: ProgressBar
    private lateinit var finishBtn: Button
    private lateinit var resComment: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        usernameText = findViewById(R.id.usernameText)
        difficultyText = findViewById(R.id.difficultyText)
        scoreText = findViewById(R.id.scoreText)
        circleProgress = findViewById(R.id.circleProgress)
        finishBtn = findViewById(R.id.finishBtn)
        resComment = findViewById(R.id.commentresult)

        val iqseekbar = findViewById<SeekBar>(R.id.iqseek)
        val iqtext = findViewById<TextView>(R.id.ValueIq)
        val username = intent.getStringExtra("username") ?: "Guest"
        val score = intent.getDoubleExtra("score", 0.0)
        val difficulty = intent.getStringExtra("difficulty") ?: "No Diffculty"
        val scoreInt = score.toInt()

        usernameText.text = "Username: $username"
        difficultyText.text = "Difficulty: $difficulty"
        scoreText.text = "%.1f / 10.0".format(score)

        val percent = (score * 10).toInt()
        ObjectAnimator.ofInt(circleProgress, "progress", 0, percent).apply {
            duration = 1500
            start()
        }


        val iqval = arrayOf(60, 65, 70, 75, 80, 85, 90, 95, 105, 115, 125, 135)
        val iq = iqval[scoreInt.coerceIn(0, 10)]

        ObjectAnimator.ofInt(iqseekbar, "progress", 0, iq).setDuration(800).start()
        iqtext.text = "IQ : $iq"


        val comment = when (scoreInt) {
            in 0..4 -> "KEEP PRACTICING"
            in 5..7 -> "KEEP GOING"
            in 8..10 -> "SHARP MIND HAS NO LIMITS"
            else -> "GREAT TRY"
        }
        resComment.text = comment

        finishBtn.setOnClickListener {
            finish()
        }
    }
}
